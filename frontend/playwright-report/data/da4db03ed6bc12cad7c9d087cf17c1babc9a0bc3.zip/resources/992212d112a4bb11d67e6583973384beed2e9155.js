(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0uf_0tt._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_0.pzobh._.js","static/chunks/node_modules_@tanstack_table-core_build_lib_index_mjs_0udnhdo._.js","static/chunks/node_modules_09uprx7._.js"],
    source: "dynamic"
});
