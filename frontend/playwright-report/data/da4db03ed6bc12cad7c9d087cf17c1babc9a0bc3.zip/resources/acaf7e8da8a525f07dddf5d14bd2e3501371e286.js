(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_0.-ko~b._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_zod_0rkd1vp._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_0.pzobh._.js","static/chunks/node_modules_0sifx-f._.js"],
    source: "dynamic"
});
