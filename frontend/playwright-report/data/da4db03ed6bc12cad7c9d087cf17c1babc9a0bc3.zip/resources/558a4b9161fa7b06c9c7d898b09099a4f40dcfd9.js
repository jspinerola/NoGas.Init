(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__08qj-uu._.css","static/chunks/node_modules_0xi64u3._.js","static/chunks/components_theme-provider_tsx_065lgkk._.js"],
    source: "dynamic"
});
